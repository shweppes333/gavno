<article>
    <img id="Image1" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQYJGp32VLiowKoW9xwcrZG7tRFta9bdyThweO53UK5Rrir4QFXhK21KejA-O_iod4ozAI&usqp=CAU" alt="Альтушка для погасших скуфов">
    <p>Elden Ring 2</p>
</article>

<style>
    img {
        width: 150px;
        height: 200px;
    }
</style>

<script>
    let image = document.querySelector('#Image1');

    let button = document.querySelector("#Button");

  button.addEventListener("click", () => {
    alert("AYAYA")
  });
</script>