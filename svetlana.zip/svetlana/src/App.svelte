<script>
  import { linear } from "svelte/easing";

  let name;
  let ul;
  let but = document.querySelector("button");
  function addtodo() {
    let li = document.createElement("li");
    console.log(ul)
    ul.append(li);
    li.innerHTML = name;
    name = "";
  }

  
</script>

<main>
  <article>
    <input id="Name" placeholder="Name" bind:value={name}/>
    <button on:click={addtodo}>Add</button>
    <button>Delete</button>
  </article>
  <ul bind:this={ul}></ul>
</main>

<style>
  .logo {
    height: 6em;
    padding: 1.5em;
    will-change: filter;
    transition: filter 300ms;
  }
  .logo:hover {
    filter: drop-shadow(0 0 2em #646cffaa);
  }
  .logo.svelte:hover {
    filter: drop-shadow(0 0 2em #ff3e00aa);
  }
  .read-the-docs {
    color: #888;
  }
  article {
    display: grid;
    gap: 10px;
    align-items: center;
  }
</style>
